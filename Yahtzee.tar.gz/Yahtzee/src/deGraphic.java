import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;


public class deGraphic {
	
	private int xCentreCarre = 0;
	private int yCentreCarre = 0;
	private int tailleCarre = 80;
	private int tailleArrondi = 10;
	private int valeur = 0;
	private Font police = new Font("times new roman", Font.BOLD, 30);
	private int pointDe[][] = new int[9][2];
	private boolean valeurPoint[][] = new boolean[6][9];
	private int taillePoint = 0;
	private boolean selected = false;
	private boolean actif = true;
	
	public deGraphic(){
		
		for (int i = 0; i < 6; i++){
			
			for (int j = 0; j < 9; j++){
				
				valeurPoint[i][j] = false;
				
			}
			
		}
		
		valeurPoint[0][4] = true;
		
		valeurPoint[1][2] = true;
		valeurPoint[1][6] = true;
		
		valeurPoint[2][2] = true;
		valeurPoint[2][4] = true;
		valeurPoint[2][6] = true;
		
		valeurPoint[3][0] = true;
		valeurPoint[3][2] = true;
		valeurPoint[3][6] = true;
		valeurPoint[3][8] = true;
		
		valeurPoint[4][0] = true;
		valeurPoint[4][2] = true;
		valeurPoint[4][4] = true;
		valeurPoint[4][6] = true;
		valeurPoint[4][8] = true;
		
		valeurPoint[5][0] = true;
		valeurPoint[5][2] = true;
		valeurPoint[5][3] = true;
		valeurPoint[5][5] = true;
		valeurPoint[5][6] = true;
		valeurPoint[5][8] = true;
		
	}
	
	public void setTaille (int centrex, int centrey, int taille){
		
		this.xCentreCarre = centrex;
		this.yCentreCarre = centrey;
		this.tailleCarre = taille;
		
	}
	
	public void dessine (Graphics g){
		
		taillePoint = tailleCarre/8;
		
		pointDe[0][0] = xCentreCarre - (5 * tailleCarre)/16;
		pointDe[3][0] = pointDe[0][0];
		pointDe[6][0] = pointDe[0][0];
		pointDe[1][0] = xCentreCarre - tailleCarre/16;
		pointDe[4][0] = pointDe[1][0];
		pointDe[7][0] = pointDe[1][0];
		pointDe[2][0] = xCentreCarre + (3* tailleCarre)/16;
		pointDe[5][0] = pointDe[2][0];
		pointDe[8][0] = pointDe[2][0];
		
		pointDe[0][1] = yCentreCarre - (5 * tailleCarre)/16;
		pointDe[1][1] = pointDe[0][1];
		pointDe[2][1] = pointDe[0][1];
		pointDe[3][1] = yCentreCarre - tailleCarre/16;
		pointDe[4][1] = pointDe[3][1];
		pointDe[5][1] = pointDe[3][1];
		pointDe[6][1] = yCentreCarre + (3* tailleCarre)/16;
		pointDe[7][1] = pointDe[6][1];
		pointDe[8][1] = pointDe[6][1];
		
		if (!actif){
			
			g.setColor(Color.gray);
			
		}else if (selected){
			
			g.setColor(Color.red);
			
		}else{
			
			g.setColor(Color.green);
			
		}
		
		g.setFont(police);
		g.fillRoundRect(xCentreCarre - (tailleCarre/2), yCentreCarre - (tailleCarre/2), tailleCarre, tailleCarre, tailleArrondi, tailleArrondi);
		
		g.setColor(Color.black);
		
		if (valeur <= 6 && valeur >= 1){
			
			for (int i = 0; i < 9; i++){
			
				if (valeurPoint[valeur-1][i]){
				
					g.fillOval(pointDe[i][0], pointDe[i][1], taillePoint, taillePoint);
				
				}
			
			}
			
		}
		
	}
	
	public void setValeur(int valeur){
		
		this.valeur = valeur;
		
	}
	
	public void setSelected(boolean selected){
		
		this.selected = selected;
		
	}
	
	public boolean contient(int x, int y){
		
		boolean retour = false;
		
		if (x <= (xCentreCarre + tailleCarre/2) && x >= (xCentreCarre - tailleCarre/2) && y <= (yCentreCarre + tailleCarre/2) && y >= (yCentreCarre - tailleCarre/2)){
			
			retour = true;
			
		}
		
		return retour;
		
	}
	
	public void setActif (boolean actif){
		
		this.actif = actif;
		
		if (!actif){
			
			this.setValeur(-1);
			
		}
		
	}
	
}
