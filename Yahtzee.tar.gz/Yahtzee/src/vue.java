import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Toolkit;

import javax.swing.JMenuBar;

import java.awt.BorderLayout;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.Timer;

import net.miginfocom.swing.MigLayout;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;


// GUYONNEAU Julien Grp 2

public class vue implements Observer{
 
	private static int valeur;
	private boolean etatGrille;
	private JFrame frmYAH;
	private JMenuBar menuBar;
	private JMenu menuLangue, menuJeu;
	private JSeparator separator1, separator2;
	
	private JMenuItem menuItemFrancais, menuItemEnglish, menuItemJouer, menuItemScores, menuItemAide, menuItemQuitter;
	
	private JPanel panelZoneJeu, panelInfos, panelCommande, panelGrille;
	
	private JLabel labelPseudo, labelDuree, labelTimer, labelGrille, labelUnTest, labelDeux, labelTrois, labelQuatre, labelCinq, labelSix, 
				   labelBrelan, labelFull, labelCarre, labelPetiteSuite, labelGrandeSuite, labelYahtzee, labelChance, labelSousTotal1, 
				   labelSousTotal2, labelBonus, labelTotal;
	
	private JButton btnLancer, btnCommencer, btnUnTest, btnDeux, btnTrois, btnQuatre, btnCinq, btnSix, btnBrelan, btnFull, btnCarre, btnPetiteSuite,
					btnGrandeSuite, btnYahtzee, btnChance, btnSousTotal1, btnSousTotal2, btnBonus, btnTotal;
	
	public static panneau panelDes;
	
	final GregorianCalendar calendar = new GregorianCalendar();
	
	private SimpleDateFormat formatDate = new SimpleDateFormat("kk:mm:ss");
	
	private dicoLangue dictionnaire;
	
	private modele MT;
	
	private controleur CT;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vue window = new vue();
					window.frmYAH.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public vue() {
		
		initialize();
		
		MT = new modele();
		CT = new controleur(MT, this);
		
		MT.addObserver(this);
		
		dictionnaire = new dicoLangue("data", "langues.txt");
		
		etatGrille = false;
		
		Dimension minimum = new Dimension(850, 500);
		frmYAH.setMinimumSize(minimum);
		frmYAH.setLocationRelativeTo(null);
		frmYAH.addWindowListener(CT);
		
		this.menuBar = new JMenuBar();
		frmYAH.getContentPane().add(menuBar, BorderLayout.NORTH);
		
		this.menuLangue = new JMenu("");
		menuBar.add(menuLangue);
		
		this.menuItemFrancais = new JMenuItem("Français");
		menuLangue.add(menuItemFrancais);
		menuItemFrancais.addActionListener(CT);
		menuItemFrancais.setActionCommand("FRANCAIS");
		
		this.menuItemEnglish = new JMenuItem("English");
		menuLangue.add(menuItemEnglish);
		menuItemEnglish.addActionListener(CT);
		menuItemEnglish.setActionCommand("ENGLISH");
		
		this.menuJeu = new JMenu("");
		menuBar.add(menuJeu);
		
		this.menuItemJouer = new JMenuItem("");
		menuJeu.add(menuItemJouer);
		menuItemJouer.addActionListener(CT);
		menuItemJouer.setActionCommand("JOUER");
		
		this.menuItemScores = new JMenuItem("");
		menuJeu.add(menuItemScores);
		menuItemScores.addActionListener(CT);
		menuItemScores.setActionCommand("SCORES");
		
		this.menuItemAide = new JMenuItem("");
		menuJeu.add(menuItemAide);
		menuItemAide.addActionListener(CT);
		menuItemAide.setActionCommand("AIDE");
		
		this.menuItemQuitter = new JMenuItem("");
		menuJeu.add(menuItemQuitter);
		menuItemQuitter.addActionListener(CT);
		menuItemQuitter.setActionCommand("QUITTER");
		
		this.panelZoneJeu = new JPanel();
		frmYAH.getContentPane().add(panelZoneJeu, BorderLayout.CENTER);
		panelZoneJeu.setLayout(new BorderLayout(0, 0));
		
		this.panelInfos = new JPanel();
		panelZoneJeu.add(panelInfos, BorderLayout.NORTH);
		panelInfos.setLayout(new MigLayout("", "[left][grow,fill][center][grow,fill][right]", "[]"));
		
		this.labelPseudo = new JLabel("");
		panelInfos.add(labelPseudo, "cell 0 0");
		
		this.labelDuree = new JLabel("");
		labelDuree.setForeground(Color.BLUE);
		panelInfos.add(labelDuree, "cell 2 0");
		
		this.labelTimer = new JLabel("");
		panelInfos.add(labelTimer, "cell 4 0");
		
		this.panelCommande = new JPanel();
		panelZoneJeu.add(panelCommande, BorderLayout.SOUTH);
		panelCommande.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		this.btnLancer = new JButton("");
		btnLancer.setEnabled(false);
		btnLancer.setVisible(false);
		panelCommande.add(btnLancer);
		btnLancer.addActionListener(CT);
		btnLancer.setActionCommand("LANCER");
		
		this.btnCommencer = new JButton("");
		panelCommande.add(btnCommencer);
		btnCommencer.addActionListener(CT);
		btnCommencer.setActionCommand("COMMENCER");
		
		this.panelGrille = new JPanel();
		panelGrille.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelZoneJeu.add(panelGrille, BorderLayout.EAST);
		panelGrille.setLayout(new MigLayout("", "[left][][][20px:n,grow,center][][][right]", "[][][][][][][][][][][][][]"));
		
		this.labelGrille = new JLabel("");
		labelGrille.setHorizontalAlignment(SwingConstants.CENTER);
		labelGrille.setOpaque(true);
		labelGrille.setForeground(Color.WHITE);
		labelGrille.setBackground(Color.GRAY);
		panelGrille.add(labelGrille, "cell 1 0 5 1,growx");
		
		this.labelUnTest = new JLabel("");
		panelGrille.add(labelUnTest, "cell 1 1,alignx right");
		
		this.btnUnTest = new JButton("000");
		btnUnTest.setEnabled(false);
		panelGrille.add(btnUnTest, "cell 2 1,growx");
		btnUnTest.addActionListener(CT);
		btnUnTest.setActionCommand("UN_TEST");
		
		this.labelBrelan = new JLabel("");
		panelGrille.add(labelBrelan, "cell 4 1,alignx right");
		
		this.btnBrelan = new JButton("000");
		btnBrelan.setEnabled(false);
		panelGrille.add(btnBrelan, "cell 5 1,growx");
		btnBrelan.addActionListener(CT);
		btnBrelan.setActionCommand("BRELAN");
		
		this.labelDeux = new JLabel("");
		panelGrille.add(labelDeux, "cell 1 2,alignx right");
		
		this.btnDeux = new JButton("000");
		btnDeux.setEnabled(false);
		panelGrille.add(btnDeux, "cell 2 2,growx");
		btnDeux.addActionListener(CT);
		btnDeux.setActionCommand("DEUX");
		
		this.labelFull = new JLabel("");
		panelGrille.add(labelFull, "cell 4 2,alignx right,growy");
		
		this.btnFull = new JButton("000");
		btnFull.setEnabled(false);
		panelGrille.add(btnFull, "cell 5 2,growx");
		btnFull.addActionListener(CT);
		btnFull.setActionCommand("FULL");
		
		this.labelTrois = new JLabel("");
		panelGrille.add(labelTrois, "cell 1 3,alignx right");
		
		this.btnTrois = new JButton("000");
		btnTrois.setEnabled(false);
		panelGrille.add(btnTrois, "cell 2 3,growx");
		btnTrois.addActionListener(CT);
		btnTrois.setActionCommand("TROIS");
		
		this.labelCarre = new JLabel("");
		panelGrille.add(labelCarre, "cell 4 3,alignx right");
		
		this.btnCarre = new JButton("000");
		btnCarre.setEnabled(false);
		panelGrille.add(btnCarre, "cell 5 3,growx");
		btnCarre.addActionListener(CT);
		btnCarre.setActionCommand("CARRE");
		
		this.labelQuatre = new JLabel("");
		panelGrille.add(labelQuatre, "cell 1 4,alignx right");
		
		this.btnQuatre = new JButton("000");
		btnQuatre.setEnabled(false);
		panelGrille.add(btnQuatre, "cell 2 4,growx");
		btnQuatre.addActionListener(CT);
		btnQuatre.setActionCommand("QUATRE");
		
		this.labelPetiteSuite = new JLabel("");
		panelGrille.add(labelPetiteSuite, "cell 4 4,alignx right");
		
		this.btnPetiteSuite = new JButton("000");
		btnPetiteSuite.setEnabled(false);
		panelGrille.add(btnPetiteSuite, "cell 5 4,growx");
		btnPetiteSuite.addActionListener(CT);
		btnPetiteSuite.setActionCommand("PETITE_SUITE");
		
		this.labelCinq = new JLabel("");
		panelGrille.add(labelCinq, "cell 1 5,alignx right");
		
		this.btnCinq = new JButton("000");
		btnCinq.setEnabled(false);
		panelGrille.add(btnCinq, "cell 2 5,growx");
		btnCinq.addActionListener(CT);
		btnCinq.setActionCommand("CINQ");
		
		this.labelGrandeSuite = new JLabel("");
		panelGrille.add(labelGrandeSuite, "cell 4 5,alignx right");
		
		this.btnGrandeSuite = new JButton("000");
		btnGrandeSuite.setEnabled(false);
		panelGrille.add(btnGrandeSuite, "cell 5 5,growx");
		btnGrandeSuite.addActionListener(CT);
		btnGrandeSuite.setActionCommand("GRANDE_SUITE");
		
		this.labelSix = new JLabel("");
		panelGrille.add(labelSix, "cell 1 6,alignx right");
		
		this.btnSix = new JButton("000");
		btnSix.setEnabled(false);
		panelGrille.add(btnSix, "cell 2 6,growx");
		btnSix.addActionListener(CT);
		btnSix.setActionCommand("SIX");
		
		this.labelYahtzee = new JLabel("");
		panelGrille.add(labelYahtzee, "cell 4 6,alignx right");
		
		this.btnYahtzee = new JButton("000");
		btnYahtzee.setEnabled(false);
		panelGrille.add(btnYahtzee, "cell 5 6,growx");
		btnYahtzee.addActionListener(CT);
		btnYahtzee.setActionCommand("YAHTZEE");
		
		this.labelChance = new JLabel("");
		panelGrille.add(labelChance, "cell 4 7,alignx right,aligny baseline");
		
		this.btnChance = new JButton("000");
		btnChance.setEnabled(false);
		panelGrille.add(btnChance, "cell 5 7,growx");
		btnChance.addActionListener(CT);
		btnChance.setActionCommand("CHANCE");
		
		this.separator1 = new JSeparator();
		separator1.setForeground(Color.GRAY);
		separator1.setOpaque(true);
		separator1.setBackground(Color.GRAY);
		panelGrille.add(separator1, "cell 1 8 5 1,growx");
		
		this.labelSousTotal1 = new JLabel("");
		panelGrille.add(labelSousTotal1, "cell 1 9,alignx right");
		
		this.btnSousTotal1 = new JButton("000");
		btnSousTotal1.setEnabled(false);
		panelGrille.add(btnSousTotal1, "cell 2 9,growx");
		btnSousTotal1.addActionListener(CT);
		btnSousTotal1.setActionCommand("SOUS_TOTAL_1");
		
		this.labelSousTotal2 = new JLabel("");
		panelGrille.add(labelSousTotal2, "cell 4 9,alignx right");
		
		this.btnSousTotal2 = new JButton("000");
		btnSousTotal2.setEnabled(false);
		panelGrille.add(btnSousTotal2, "cell 5 9,growx");
		btnSousTotal2.addActionListener(CT);
		btnSousTotal2.setActionCommand("SOUS_TOTAL_2");
		
		this.labelBonus = new JLabel("");
		panelGrille.add(labelBonus, "cell 1 10,alignx right");
		
		this.btnBonus = new JButton("000");
		btnBonus.setEnabled(false);
		panelGrille.add(btnBonus, "cell 2 10,growx");
		btnBonus.addActionListener(CT);
		btnBonus.setActionCommand("BONUS");
		
		this.separator2 = new JSeparator();
		separator2.setForeground(Color.GRAY);
		separator2.setOpaque(true);
		separator2.setBackground(Color.GRAY);
		panelGrille.add(separator2, "cell 1 11 5 1,growx");
		
		this.labelTotal = new JLabel(" TOTAL :");
		panelGrille.add(labelTotal, "cell 2 12 2 1,alignx right");
		
		this.btnTotal = new JButton("000");
		btnTotal.setEnabled(false);
		panelGrille.add(btnTotal, "cell 4 12,growx");
		btnTotal.addActionListener(CT);
		btnTotal.setActionCommand("TOTAL");
		
		this.panelDes = new panneau();
		panelDes.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelZoneJeu.add(panelDes, BorderLayout.CENTER);
		panelDes.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panelDes.addMouseListener(CT);
		
		renduTexte();
		
		MT.deserialiserScores();
		
		horloge(true);
		chrono(false);
		
	}

	
	private void initialize() {
		frmYAH = new JFrame();
		frmYAH.setIconImage(Toolkit.getDefaultToolkit().getImage(vue.class.getResource("/images/fleur.png")));
		frmYAH.setTitle("Y A H T Z E E");
		frmYAH.setBounds(100, 100, 450, 300);
		frmYAH.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	
	public void update(Observable arg0, Object arg1) {
		
		modele MT = (modele)arg0;
		panelDes.changeValeurs(MT.getValeurs());
		panelDes.setSelection(MT.getSelection());
		panelDes.setActivite(MT.isDesActifs());
		panelDes.setNumLancer(MT.getNumLancer());
		panelDes.setNumTour(MT.getNumTour());
		panelDes.repaint();
		
		if (MT.isTour() && !etatGrille){
			
			chrono(true);
			setEtatGrille(true);
			setEtatCommandes(true);
			
		}else if (!MT.isTour()){
			
			chrono(false);
			setEtatGrille(false);
			setEtatCommandes(false);
			
		}

		setScores(MT);
		renduTexte();
		
	}
	
	public boolean[] testSelection(int x, int y) {
		
		return panelDes.testSelection(x, y);
		
	}
	
	public void setLangue(String lg){
		
		panelDes.setLangue(lg);
		dictionnaire.setLangue(lg);
		
	}
	
	public String getLangue(){
		
		return dictionnaire.getLangue();
		
	}
	
	public void setActivite (boolean actif){
		
		panelDes.setActivite(actif);
		
	}
	
	public void horloge(boolean actif){
		
		if (actif){
			
			horloge.start();
			
		}else{
			
			horloge.stop();
			
		}
		
	}
	
	public void chrono(boolean actif){
		
		if (actif){
			
			chrono.start();
			
		}else{
			
			chrono.stop();
			valeur = 0;
			labelDuree.setText("00:00");
			
		}
		
	}
	
	public void renduTexte(){
		
		String texte = dictionnaire.getTexte("ScoreScore");
		labelGrille.setText(texte);
		texte = dictionnaire.getTexte("ScoreUn");
		labelUnTest.setText(texte);
		texte = dictionnaire.getTexte("ScoreDeux");
		labelDeux.setText(texte);
		texte = dictionnaire.getTexte("ScoreTrois");
		labelTrois.setText(texte);
		texte = dictionnaire.getTexte("ScoreQuatre");
		labelQuatre.setText(texte);
		texte = dictionnaire.getTexte("ScoreCinq");
		labelCinq.setText(texte);
		texte = dictionnaire.getTexte("ScoreSix");
		labelSix.setText(texte);
		texte = dictionnaire.getTexte("ScoreBrelan");
		labelBrelan.setText(texte);
		texte = dictionnaire.getTexte("ScoreCarre");
		labelCarre.setText(texte);
		texte = dictionnaire.getTexte("ScoreFull");
		labelFull.setText(texte);
		texte = dictionnaire.getTexte("ScorePSuite");
		labelPetiteSuite.setText(texte);
		texte = dictionnaire.getTexte("ScoreGSuite");
		labelGrandeSuite.setText(texte);
		texte = dictionnaire.getTexte("ScoreYahtzee");
		labelYahtzee.setText(texte);
		texte = dictionnaire.getTexte("ScoreChance");
		labelChance.setText(texte);
		texte = dictionnaire.getTexte("ScoreSTotal1");
		labelSousTotal1.setText(texte);
		texte = dictionnaire.getTexte("ScoreSTotal2");
		labelSousTotal2.setText(texte);
		texte = dictionnaire.getTexte("ScoreBonus");
		labelBonus.setText(texte);
		texte = dictionnaire.getTexte("ScoreTotal");
		labelTotal.setText(texte);
		texte = dictionnaire.getTexte("BoutonCommencer");
		btnCommencer.setText(texte);
		texte = dictionnaire.getTexte("BoutonLancer");
		btnLancer.setText(texte);
		texte = dictionnaire.getTexte("MenuLangue");
		menuLangue.setText(texte);
		texte = dictionnaire.getTexte("MenuJeu");
		menuJeu.setText(texte);
		texte = dictionnaire.getTexte("MenuJouer");
		menuItemJouer.setText(texte);
		texte = dictionnaire.getTexte("MenuScores");
		menuItemScores.setText(texte);
		texte = dictionnaire.getTexte("MenuAide");
		menuItemAide.setText(texte);
		texte = dictionnaire.getTexte("MenuQuitter");
		menuItemQuitter.setText(texte);
		texte = MT.getPseudo();
		labelPseudo.setText(texte);
		
		
	}
	
	public void setEtatGrille (boolean etat){
		
		btnUnTest.setEnabled(etat);
		btnDeux.setEnabled(etat);
		btnTrois.setEnabled(etat);
		btnQuatre.setEnabled(etat);
		btnCinq.setEnabled(etat);
		btnSix.setEnabled(etat);
		btnBrelan.setEnabled(etat);
		btnFull.setEnabled(etat);
		btnCarre.setEnabled(etat);
		btnPetiteSuite.setEnabled(etat);
		btnGrandeSuite.setEnabled(etat);
		btnYahtzee.setEnabled(etat);
		btnChance.setEnabled(etat);
		btnSousTotal1.setEnabled(etat);
		btnSousTotal2.setEnabled(etat);
		btnBonus.setEnabled(etat);
		btnTotal.setEnabled(etat);
		
		etatGrille = etat;
		
	}
	
	public void setEtatCommandes (boolean tour){
		
		if (tour){
			
			btnCommencer.setEnabled(false);
			btnCommencer.setVisible(false);
			btnLancer.setEnabled(true);
			btnLancer.setVisible(true);
			
		}else{
			
			btnLancer.setEnabled(false);
			btnLancer.setVisible(false);
			btnCommencer.setEnabled(true);
			btnCommencer.setVisible(true);
			
		}
		
	}
	
	public void setScores(modele MT){
		
		btnUnTest.setText(""+MT.getLesScores().getScoreUn());
		btnDeux.setText(""+MT.getLesScores().getScoreDeux());
		btnTrois.setText(""+MT.getLesScores().getScoreTrois());
		btnQuatre.setText(""+MT.getLesScores().getScoreQuatre());
		btnCinq.setText(""+MT.getLesScores().getScoreCinq());
		btnSix.setText(""+MT.getLesScores().getScoreSix());
		btnBrelan.setText(""+MT.getLesScores().getScoreBrelan());
		btnFull.setText(""+MT.getLesScores().getScoreFull());
		btnCarre.setText(""+MT.getLesScores().getScoreCarre());
		btnPetiteSuite.setText(""+MT.getLesScores().getScorePSuite());
		btnGrandeSuite.setText(""+MT.getLesScores().getScoreGSuite());
		btnYahtzee.setText(""+MT.getLesScores().getScoreYahtzee());
		btnChance.setText(""+MT.getLesScores().getScoreChance());
		btnSousTotal1.setText(""+MT.getLesScores().getScoreSTotal1());
		btnSousTotal2.setText(""+MT.getLesScores().getScoreSTotal2());
		btnBonus.setText(""+MT.getLesScores().getScoreBonus());
		btnTotal.setText(""+MT.getLesScores().getScoreTotal());
		
	}
	
	public JButton getBtnLancer() {
		return btnLancer;
	}


	public JButton getBtnCommencer() {
		return btnCommencer;
	}


	public JButton getBtnUnTest() {
		return btnUnTest;
	}


	public JButton getBtnDeux() {
		return btnDeux;
	}


	public JButton getBtnTrois() {
		return btnTrois;
	}


	public JButton getBtnQuatre() {
		return btnQuatre;
	}


	public JButton getBtnCinq() {
		return btnCinq;
	}


	public JButton getBtnSix() {
		return btnSix;
	}


	public JButton getBtnBrelan() {
		return btnBrelan;
	}


	public JButton getBtnFull() {
		return btnFull;
	}


	public JButton getBtnCarre() {
		return btnCarre;
	}


	public JButton getBtnPetiteSuite() {
		return btnPetiteSuite;
	}


	public JButton getBtnGrandeSuite() {
		return btnGrandeSuite;
	}


	public JButton getBtnYahtzee() {
		return btnYahtzee;
	}


	public JButton getBtnChance() {
		return btnChance;
	}
	
	public static int getValeur(){
		
		return valeur;
		
	}

	///////////////////////////////////////////////////////////////////
	//						CLASSES ANONYMES					     //
	///////////////////////////////////////////////////////////////////
	
	Timer chrono = new Timer(1000, new ActionListener() {
		
		
		public void actionPerformed(ActionEvent e) {
			
			valeur++;
			String chrono = "";
			
			if (valeur/60 < 10){
				
				chrono = "0"+valeur/60+":";
				
			}else{
				
				chrono = ""+valeur/60+":";
				
			}
			
			if (valeur%60 < 10){
				
				chrono = chrono+"0"+valeur%60;
				
			}else{
				
				chrono = chrono+valeur%60;
				
			}
			
			labelDuree.setText(chrono);
			
		}
	});
	
	Timer horloge = new Timer(1000, new ActionListener() {
		
		
		public void actionPerformed(ActionEvent e) {
			
			calendar.setTimeInMillis(System.currentTimeMillis());
			
			labelTimer.setText(formatDate.format(calendar.getTime()));
			
		}
	});
	
}
