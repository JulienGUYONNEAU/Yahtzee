

public class de implements Comparable<de>{
	
	private int valeur;
	private boolean selectionne = false;
	
	public de(){
		
		valeur = -1;
		
	}
	
	public void lanceLeDe(){
		
		if (selectionne){
			
			this.valeur = (int)((Math.random()*6)+1);
			
		}
	}
	
	public int getValeur(){
		
		return valeur;
		
	}

	public int compareTo(de o) {
		
		if (this.valeur < o.getValeur()){
			
			return -1;
			
		}else if (this.valeur > o.getValeur()){
			
			return 1;
			
		}
		
		return 0;
	
	}
	
	public void selection() {
		
		if (selectionne){
			
			selectionne = false;
			
		}else{
			
			selectionne = true;
			
		}
		
	}
	
	public boolean getSelection(){
		
		return selectionne;
		
	}
	
	public void setSelection(boolean selection){
		
		this.selectionne = selection;
		
	}
	
}
