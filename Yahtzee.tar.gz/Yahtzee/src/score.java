import java.io.Serializable;


public class score implements Comparable<score> , Serializable{


	private static final long serialVersionUID = 6145787574108759163L;
	private String pseudo = null;
	private int valeur = 0;
	private int temps = 0;
	
	public score(String pseudo, int valeur, int temps){
		
		this.pseudo = pseudo;
		this.valeur = valeur;
		this.temps = temps;
		
	}
	
	public int compareTo(score param) {
		
		if (valeur > param.getValeur()){
			
			return 1;
			
		}else if (valeur < param.getValeur()){
			
			return -1;
			
		}else if (temps < param.getTemps()){
			
			return 1;
			
		}else if (temps > param.getTemps()){
			
			return -1;
			
		}
		
		return 0;
	}

	public String getPseudo() {
		
		return pseudo;
	
	}

	public int getValeur() {
	
		return valeur;
	
	}

	public int getTemps() {
	
		return temps;
	
	}
	
	
	
}
