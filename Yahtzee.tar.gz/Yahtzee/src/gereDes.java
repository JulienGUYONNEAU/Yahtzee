
public class gereDes {
	
	public gereDes(){}
	
	public void Lancer(){
		
		for (int i = 0; i < 5; i++){
			
			modele.getDes(i).lanceLeDe();
			
		}
	
	}
	
	public int[] getValeur(){
		
		int valeurs[] = new int[5];
		
		for (int i = 0; i < 5; i++){
			
			valeurs[i] = modele.getDes(i).getValeur();
			
		}
		
		return valeurs;
		
	}
	
	public void setSelection(boolean resultat[]){
		
		for (int i = 0; i < 5; i++){
			
			if (resultat[i]){
				
				modele.getDes(i).selection();
				
			}
			
		}
		
	}
	
	public boolean[] getSelection(){
		
		boolean retour[] = new boolean[5];
		
		for (int i = 0; i < 5; i++){
			
			retour[i] = modele.getDes(i).getSelection();
			
		}
		
		return retour;
		
	}
	
	public void allSelection(boolean etat){
		
		for (int i = 0; i < 5; i++){
			
				modele.getDes(i).setSelection(etat);
			
		}
		
	}
	
}
