

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Observable;
import java.util.TreeSet;

public class modele extends Observable{
	
	private int total, numLancer, numTour;
	private final int NBLANCER = 3;
	private final int NBTOUR = 13;
	private boolean nouveauJeu, tour, score, desActifs, dernierLancer;
	private gereDes lesDes;
	private gereScore lesScores;
	private String pseudo;
	private static ArrayList<de> des = new ArrayList<de>();
	public static TreeSet<score> scores = new TreeSet<score>();
	
	public modele(){
		
		super();
		this.lesDes = new gereDes();
		this.lesScores = new gereScore(this);
		this.pseudo = "";
		this.total = 0;
		this.nouveauJeu = false;
		this.tour = false;
		this.score = false;
		this.desActifs = false;
		this.dernierLancer = false;
		
		de de1 = new de();
		de de2 = new de();
		de de3 = new de();
		de de4 = new de();
		de de5 = new de();
		
		des.add(de1);
		des.add(de2);
		des.add(de3);
		des.add(de4);
		des.add(de5);
		
	}
	
	public boolean isNouveauJeu() {
		
		return nouveauJeu;
	
	}

	public void setNouveauJeu(boolean nouveauJeu) {
		
		if (nouveauJeu){
			
			this.setTour(false);
			this.setScore(false);
			this.setDesActifs(false);
			this.dernierLancer = false;
			this.setNumLancer(-1);
			this.setNumTour(-1);
			this.setPseudo("pseudo");
			lesScores.reset();
			
		}
		this.nouveauJeu = nouveauJeu;
	
	}

	public boolean isTour() {
		
		return tour;
	
	}

	public void setTour(boolean tour) {
		
		if (tour){
			
			this.setNouveauJeu(false);
			this.setScore(false);
			this.setDesActifs(false);
			this.lesDes.allSelection(true);
			this.numLancer = 0;
			this.numTour = 1;
			
		}
		this.tour = tour;
	
	}

	public boolean isScore() {
		
		return score;
	
	}

	public void setScore(boolean score) {
		
		if (score){
			
			this.setNouveauJeu(false);
			this.setTour(false);
			score resultat = new score(pseudo, lesScores.getScoreTotal(), vue.getValeur());
			
			if (scores.size() < 10){
				
				scores.add(resultat);
				
			}else{
				
				scores.add(resultat);
				scores.remove(scores.first());
				
			}
			
			this.setNouveauJeu(true);
			
		}
		
		this.score = score;
		this.refresh();
	
	}

	public void refresh() {
		
		setChanged();
		notifyObservers();
		
	}
	
	public void Lancer(){
		
		boolean areSelected = false;
		
		for (int i = 0; i < 5; i++){
			
			if (this.getSelection()[i]){
				
				areSelected = true;
				
			}
			
		}
		
		if ((numTour <= NBTOUR) && areSelected){
			
			if (numTour == 7){
				
				lesScores.testBonus();
				
			}
			
			if (numLancer < NBLANCER){
				
				this.setDesActifs(true);
				this.lesDes.Lancer();
				this.lesDes.allSelection(false);
				numLancer++;
				
				if (numLancer == 3){
					
					dernierLancer = true;
					
				}
				
			}else{
				
				numLancer = 0;
				this.setDesActifs(false);
				this.lesDes.allSelection(true);
				
				if (numTour != NBTOUR){
					
					numTour++;
				
				}else if (numTour == NBTOUR){
					
					numTour = 0;
					this.setScore(true);
					
				}
				
			}
			
			
		}
		
		
	}
	
	public void setSelection(boolean resultat[]){
		
		if (tour && desActifs){
			
			this.lesDes.setSelection(resultat);
		
		}
		
	}
	
	public boolean[] getSelection(){
		
		return this.lesDes.getSelection();
		
	}
	
	public int[] getValeurs(){
		
		return lesDes.getValeur();
		
	}
	
	public int getTotal(){
		
		return this.total;
		
	}
	
	public static de getDes(int i) {
		
		return des.get(i);
		
	}
	
	public void setPseudo(String pseudo){
		
		this.pseudo = pseudo;
		
	}
	
	public String getPseudo(){
		
		return this.pseudo;
		
	}

	public int getNumLancer() {
		
		return numLancer;
	
	}

	public void setNumLancer(int numLancer) {
		
		this.numLancer = numLancer;
	
	}

	public int getNumTour() {
	
		return numTour;
	
	}

	public void setNumTour(int numTour) {
	
		this.numTour = numTour;
	
	}
	
	public void setDesActifs (boolean desActifs){
		
	this.desActifs = desActifs;
		
	}
	
	public boolean isDesActifs(){
		
		return desActifs;
		
	}
	
	public void ajouterScore (String figure){
		
		if (desActifs){
			
			lesScores.setScore(figure);
			
			numLancer = 0;
			dernierLancer = false;
			this.setDesActifs(false);
			this.lesDes.allSelection(true);
			
			if (numTour != NBTOUR){
				
				numTour++;
			
			}else if (numTour == NBTOUR){
				
				numTour = 0;
				this.setScore(true);
				
			}
			
		}
		
	}
	
	public gereScore getLesScores(){
		
		return lesScores;
		
	}
	
	public boolean isDernierLancer(){
		
		return dernierLancer;
		
	}
	
	public void serialiserScores(){
		
		File repertoire = new File("data");
		repertoire.mkdir();
		File scores = new File(repertoire, "scores.bin");
		
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(scores))){
			
			oos.writeObject(modele.scores);
			
		}catch (Exception e){
			
			System.out.println(e.getMessage());
			
		}
		
	}
	
	public void deserialiserScores(){
		
		File repertoire = new File("data");
		repertoire.mkdir();
		File scores = new File(repertoire, "scores.bin");
		
		if (!scores.exists()){
			
			System.out.println("Fichier "+scores.getName()+ " introuvable!");
			return;
			
		}
		
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(scores))){
			
			modele.scores = (TreeSet<score>) ois.readObject();
			
		}catch (Exception e){
			
			System.out.println(e.getMessage());
			
		}
		
	}
	
}
