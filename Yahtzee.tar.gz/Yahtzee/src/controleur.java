import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;
import javax.swing.text.html.HTMLDocument.Iterator;



public class controleur implements ActionListener, WindowListener, MouseListener{
	
	private modele monModele;
	private vue maVue;
	
	public controleur(modele MT, vue V) {
		
		this.monModele = MT;
		this.maVue = V;
		
	}
	
	public void windowActivated(WindowEvent e) {
		
	}

	public void windowClosed(WindowEvent e) {
		
	}

	public void windowClosing(WindowEvent e) {
		
		monModele.serialiserScores();
		
	}

	public void windowDeactivated(WindowEvent e) {
		
	}

	public void windowDeiconified(WindowEvent e) {
		
	}

	public void windowIconified(WindowEvent e) {
		
	}

	public void windowOpened(WindowEvent e) {
		
		maVue.setLangue("FR");
		monModele.setNouveauJeu(true);
		monModele.refresh();
		
	}

	
	public void actionPerformed(ActionEvent e) {
		
		if (e.getActionCommand().equals("FRANCAIS")){
			
			maVue.setLangue("FR");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("ENGLISH")){
			
			maVue.setLangue("EN");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("JOUER")) {
			
			monModele.setNouveauJeu(true);
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("SCORES")) {
			
			StringBuffer scores = new StringBuffer();
			String temps = "";
			java.util.Iterator<score> iter = monModele.scores.descendingIterator();

			while (iter.hasNext()){
				
				score cache = iter.next();
				
				if (cache.getTemps()/60 < 10){
					
					temps = "0"+cache.getTemps()/60+":";
					
				}else{
					
					temps = ""+cache.getTemps()/60+":";
					
				}
				
				if (cache.getTemps()%60 < 10){
					
					temps = temps+"0"+cache.getTemps()%60;
					
				}else{
					
					temps = temps+cache.getTemps()%60;
					
				}
				
				scores.append(cache.getPseudo()+" "+cache.getValeur()+" "+temps+"\n");
				temps = "";
				
			}
			
			JOptionPane.showMessageDialog(null, scores, "SCORES", JOptionPane.INFORMATION_MESSAGE);
			
		}else if (e.getActionCommand().equals("AIDE")) {
			
			if (maVue.getLangue().equals("FR")){
				
				JOptionPane.showMessageDialog(null, "Google est ton ami", "AIDE", JOptionPane.INFORMATION_MESSAGE);
				
			}else if (maVue.getLangue().equals("EN")){
				
				JOptionPane.showMessageDialog(null, "Google is your friend", "HELP", JOptionPane.INFORMATION_MESSAGE);
				
			}
			
		}else if (e.getActionCommand().equals("QUITTER")) {
			
			monModele.serialiserScores();
			System.exit(0);
			
		}else if (e.getActionCommand().equals("LANCER")) {
			
			this.monModele.Lancer();
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("COMMENCER")) {
			
			String pseudo = "";
			
			if (maVue.getLangue().equals("FR")){
				
				pseudo = JOptionPane.showInputDialog(null, "Entrez votre pseudo (3 à 8 lettres) : ", "PSEUDO", JOptionPane.QUESTION_MESSAGE);
				
			}else if (maVue.getLangue().equals("EN")){
				
				pseudo = JOptionPane.showInputDialog(null, "Enter your nickname (3 to 8 letters) : ", "NICKNAME", JOptionPane.QUESTION_MESSAGE);
				
			}
			
			if (pseudo != null){
				
				if ((pseudo.length() >= 3) && (pseudo.length() <= 8)){
					
					monModele.setPseudo(pseudo);
					monModele.setTour(true);
					monModele.refresh();
					
				}
				
			}
			
		}else if (e.getActionCommand().equals("UN_TEST")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnUnTest().setEnabled(false);
				
			}
			
			monModele.ajouterScore("UN");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("DEUX")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnDeux().setEnabled(false);
				
			}
			
			monModele.ajouterScore("DEUX");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("TROIS")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnTrois().setEnabled(false);
				
			}
			
			monModele.ajouterScore("TROIS");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("QUATRE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnQuatre().setEnabled(false);
				
			}
			
			monModele.ajouterScore("QUATRE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("CINQ")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnCinq().setEnabled(false);
				
			}
			
			monModele.ajouterScore("CINQ");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("SIX")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnSix().setEnabled(false);
				
			}
			
			monModele.ajouterScore("SIX");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("BRELAN")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnBrelan().setEnabled(false);
				
			}
			
			monModele.ajouterScore("BRELAN");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("CARRE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnCarre().setEnabled(false);
				
			}
			
			monModele.ajouterScore("CARRE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("FULL")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnFull().setEnabled(false);
				
			}
			
			monModele.ajouterScore("FULL");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("PETITE_SUITE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnPetiteSuite().setEnabled(false);
				
			}
			
			monModele.ajouterScore("PSUITE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("GRANDE_SUITE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnGrandeSuite().setEnabled(false);
				
			}
			
			monModele.ajouterScore("GSUITE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("YAHTZEE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnYahtzee().setEnabled(false);
				
			}
			
			monModele.ajouterScore("YAHTZEE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("CHANCE")) {
			
			if (monModele.isDesActifs()){
				
				maVue.getBtnChance().setEnabled(false);
				
			}
			
			monModele.ajouterScore("CHANCE");
			monModele.refresh();
			
		}else if (e.getActionCommand().equals("SOUS_TOTAL_1")) {
			
		}else if (e.getActionCommand().equals("SOUS_TOTAL_2")) {
			
		}else if (e.getActionCommand().equals("TOTAL")) {
			
		}
		
		if (monModele.isDernierLancer()){
			
			maVue.getBtnLancer().setEnabled(false);
			
		}else{
			
			maVue.getBtnLancer().setEnabled(true);
		
		}
		
	}

	public void mouseClicked(MouseEvent e) {
		
		if ((e.getSource() == vue.panelDes) && maVue.getBtnLancer().isEnabled()){
			
			this.monModele.setSelection(this.maVue.testSelection(e.getX(), e.getY()));
			monModele.refresh();
			
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
}
