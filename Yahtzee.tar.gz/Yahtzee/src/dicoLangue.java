import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;


public class dicoLangue {

	private File repertoire;
	private File fichier;
	private String nom;
	private String langue;
	private HashMap<String, String> mots = new HashMap<String, String>();
	
	public dicoLangue (String rep, String nom){
		
		repertoire = new File(rep);
		repertoire.mkdir();
		fichier = new File(repertoire, nom);
		this.nom = nom;
		this.langue = "";
		lectureFichier();
		
	}
	
	public void setLangue (String langue){
		
		this.langue = langue;
		lectureFichier();
		
	}
	
	public String getLangue(){
		
		return langue;
		
	}
	
	public String getTexte (String identifiant){
		
		if (mots.containsKey(identifiant)){
			
			return mots.get(identifiant);
			
		}
		
		return "";

	}
	
	public void lectureFichier(){
		
		if (!fichier.exists()){
		
			System.out.println("Fichier "+fichier.getName()+ " introuvable!");
			return;
			
		}else if ((!langue.toUpperCase().equals("FR") && !langue.toUpperCase().equals("EN"))){
			
			return;
			
		}
	
		mots.clear();
		
		StringBuffer lecture = new StringBuffer();
		int nbLigne = 0;
		
		try (BufferedReader br = new BufferedReader(new FileReader(fichier))){
			
			String ligne = null;
			
			ligne = br.readLine();
			
			while (ligne != null){
				
				if (!ligne.startsWith("//")){
				
					nbLigne++;
				
				}
				
				ligne = br.readLine();
				
			}
			
			lecture = lecture.append(nbLigne+" ligne(s)\n\n");
			
			
		
		}catch (Exception e){
			
			System.out.println(e.getMessage());
			System.out.println();
			
		}
		
		String tabID[] = new String[nbLigne];
		String tabFR[] = new String[nbLigne];
		String tabEN[] = new String[nbLigne];
		
		try (BufferedReader br = new BufferedReader(new FileReader(fichier))){
			
			String ligne = null;
			ligne = br.readLine();
			String split[];
			int i = 0;
			
			while (ligne != null){
				
				if (!ligne.startsWith("//")){
					
					split = ligne.split(";");
					tabID[i] = split[0];
					tabFR[i] = split[1].substring(3);
					tabEN[i] = split[2].substring(3);
					i++;
					
				}
				
				ligne = br.readLine();
				
			}
			
		}catch (Exception e){
			
			System.out.println(e.getMessage());
			System.out.println();
			
		}
		
		if (langue.toUpperCase().equals("FR")){
			
			for (int i = 0; i < tabID.length; i++){
				
				mots.put(tabID[i], tabFR[i]);
				
			}
			
		}else{
			
			for (int i = 0; i < tabID.length; i++){
				
				mots.put(tabID[i], tabEN[i]);
				
			}
			
		}
		
		
	}
	
	public void afficheDico(){
		
		for (Map.Entry<String, String> i : mots.entrySet()){
			
			System.out.println("Id : "+i.getKey()+" Texte : "+i.getValue());
			
		}
		
	}
	
}
