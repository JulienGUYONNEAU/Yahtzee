
public class gereScore {

		
	private int compteur, scoreUn, scoreDeux, scoreTrois, scoreQuatre, scoreCinq, scoreSix, scoreChance, scoreBrelan, scoreCarre, scoreFull, scorePSuite, scoreGSuite,
				scoreYahtzee,scoreSTotal1, scoreSTotal2, scoreBonus, scoreTotal;
	
	private boolean  isScoreUn, isScoreDeux, isScoreTrois, isScoreQuatre, isScoreCinq, isScoreSix, isScoreBrelan, isScoreCarre, isScoreFull, isScorePSuite, isScoreGSuite, 
					 isScoreYahtzee, isScoreChance;
	
	private int lancer[];
	private int bilan[][];
	private modele MT;
	
	
	public gereScore (modele MT){
		
		this.MT = MT;
		compteur = 0;
		scoreUn = 0;
		scoreDeux = 0; 
		scoreTrois = 0; 
		scoreQuatre = 0; 
		scoreCinq = 0; 
		scoreSix = 0; 
		scoreBrelan = 0; 
		scoreCarre = 0; 
		scoreFull = 0; 
		scorePSuite = 0; 
		scoreGSuite = 0; 
		scoreYahtzee = 0; 
		scoreSTotal1 = 0; 
		scoreSTotal2 = 0; 
		scoreChance = 0; 
		scoreTotal = 0;
		isScoreUn = false;
		isScoreDeux = false;
		isScoreTrois = false;
		isScoreQuatre = false;
		isScoreCinq = false;
		isScoreSix = false;
		isScoreBrelan = false;
		isScoreCarre = false;
		isScoreFull = false;
		isScorePSuite = false;
		isScoreGSuite = false;
		isScoreYahtzee = false;
		isScoreChance = false;
		lancer = new int[5];
		bilan = new int[6][2];
		
		
	}
	
	public void reset(){
		
		compteur = 0;
		scoreUn = 0;
		scoreDeux = 0; 
		scoreTrois = 0; 
		scoreQuatre = 0; 
		scoreCinq = 0; 
		scoreSix = 0; 
		scoreBrelan = 0; 
		scoreCarre = 0; 
		scoreFull = 0; 
		scorePSuite = 0; 
		scoreGSuite = 0; 
		scoreYahtzee = 0; 
		scoreSTotal1 = 0; 
		scoreSTotal2 = 0; 
		scoreChance = 0; 
		scoreTotal = 0;
		isScoreUn = false;
		isScoreDeux = false;
		isScoreTrois = false;
		isScoreQuatre = false;
		isScoreCinq = false;
		isScoreSix = false;
		isScoreBrelan = false;
		isScoreCarre = false;
		isScoreFull = false;
		isScorePSuite = false;
		isScoreGSuite = false;
		isScoreYahtzee = false;
		isScoreChance = false;
		
	}
	
	public void setScore (String figure){
		
		lancer = MT.getValeurs();
		int cache = 0;
		
		if (figure.equals("UN") && !isScoreUn){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 1){
					
					cache++;
					
				}
				
			}
			
			scoreUn = cache;
			isScoreUn = true;
		
		}else if (figure.equals("DEUX") && !isScoreDeux){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 2){
					
					cache += 2;
					
				}
				
			}
			
			scoreDeux = cache;
			isScoreDeux = true;
			
		}else if (figure.equals("TROIS") && !isScoreTrois){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 3){
					
					cache += 3;
					
				}
				
			}
			
			scoreTrois = cache;
			isScoreTrois = true;
			
		}else if (figure.equals("QUATRE") && !isScoreQuatre){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 4){
					
					cache += 4;
					
				}
				
			}
			
			scoreQuatre = cache;
			isScoreQuatre = true;
			
		}else if (figure.equals("CINQ") && !isScoreCinq){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 5){
					
					cache += 5;
					
				}
				
			}
			
			scoreCinq = cache;
			isScoreCinq = true;
			
		}else if (figure.equals("SIX") && !isScoreSix){
			
			for (int i = 0; i < 5; i++){
				
				if (lancer[i] == 6){
					
					cache += 6;
					
				}
				
			}
			
			scoreSix = cache;
			isScoreSix = true;
			
		}else if (figure.equals("CHANCE") && !isScoreChance){
			
			for (int i = 0; i < 5; i++){
				
				cache = cache + lancer[i];
				
			}
			
			scoreChance = cache;
			isScoreChance = true;
			
		}else if (figure.equals("BRELAN") && !isScoreBrelan){
			
			if (testFigure(figure)){
				
				for (int i = 0; i < 5; i++){
					
					cache = cache + lancer[i];
					
				}
				
				scoreBrelan = cache;
				isScoreBrelan = true;
				
			}else{
				
				scoreBrelan = 0;
				isScoreBrelan = true;
				
			}
			
			
		}else if (figure.equals("CARRE") && !isScoreCarre){
			
			if (testFigure(figure)){
				
				for (int i = 0; i < 5; i++){
					
					cache = cache + lancer[i];
					
				}
				
				scoreCarre = cache;
				isScoreCarre = true;
				
			}else{
				
				scoreCarre = 0;
				isScoreCarre = true;
				
			}
			
		}else if (figure.equals("FULL") && !isScoreFull){
			
			if (testFigure(figure)){
				
				scoreFull = 25;
				isScoreFull = true;
				
			}else{
				
				scoreFull = 0;
				isScoreFull = true;
				
			}
			
		}else if (figure.equals("PSUITE") && !isScorePSuite){
			
			if (testFigure(figure)){
				
				scorePSuite = 30;
				isScorePSuite = true;
				
			}else{
				
				scorePSuite = 0;
				isScorePSuite = true;
				
			}
			
		}else if (figure.equals("GSUITE") && !isScoreGSuite){
			
			if (testFigure(figure)){
				
				scoreGSuite = 40;
				isScoreGSuite = true;
				
			}else{
				
				scoreGSuite = 0;
				isScoreGSuite = true;
				
			}
			
		}else if ((figure.equals("YAHTZEE") && !isScoreYahtzee)){
			
			if (testFigure(figure)){
				
				scoreYahtzee = 50;
				isScoreYahtzee = true;
				
			}else{
				
				scoreYahtzee = 0;
				isScoreYahtzee = true;
				
			}
			
		}
		
		scoreSTotal1 = scoreUn + scoreDeux + scoreTrois + scoreQuatre + scoreCinq + scoreSix;
		scoreSTotal2 = scoreBrelan + scoreCarre + scoreFull + scorePSuite + scoreGSuite + scoreYahtzee + scoreChance;
		scoreTotal = scoreSTotal1 + scoreSTotal2 + scoreBonus;
		
	}
	
	public void testBonus(){
		
		if (scoreTotal >= 62){
			
			scoreBonus = 35;
			
		}
		
		scoreTotal = scoreSTotal1 + scoreSTotal2 + scoreBonus;
		
	}
	
	public boolean testFigure (String figure){
		
		String cache = "";
		
		for (int i = 0; i < 6; i++){
			
			bilan[i][0] = i + 1;
			bilan[i][1] = 0;
		
		}
		
		lancer = MT.getValeurs();
		
		for (int i = 0; i < 5; i++){
			
			bilan[lancer[i] - 1][1]++;
			
		}
		
		for (int i = 0; i < 6; i++){
			
			if (bilan[i][1] > compteur){
				
				compteur = bilan[i][1];
				
			}
			
		}
		
		if (compteur == 5){
			
			cache = "YAHTZEE";
			
		}else if (compteur == 4){
			
			cache = "CARRE";
			
		}else if (compteur == 3){
			
			for (int i = 0; i < 6; i++){
				
				if (bilan[i][1] == 2){
					
					compteur = bilan[i][1];
					
				}
				
			}
			
			if (compteur == 2){
				
				cache = "FULL";
				
			}else{
				
				cache = "BRELAN";
				
			}
			
			
		}else if (compteur == 2){
			
			int repetitions = 0;
			
			for (int i = 0; i < 6; i++){
				
				if (bilan[i][1] == 2){
					
					repetitions++;
					
				}
				
			}
			
			if (repetitions > 1){
				
				cache = "Pas de figure";
				
			}else{
				
				if (((bilan[4][1] == 0) && (bilan[5][1] == 0)) || ((bilan[0][1] == 0) && (bilan[5][1] == 0)) || ((bilan[0][1] == 0) && (bilan[1][1] == 0))){
					
					cache = "PSUITE";
					
				}else{
					
					cache = "Pas de figure";
					
				}	
			}
			
		}else if (compteur == 1){
			
			if ((bilan[0][1] == 0) || (bilan[5][1] == 0)){
				
				cache = "GSUITE";
				
			}else if ((bilan[4][1] == 0) || (bilan[1][1] == 0)){
				
				cache = "PSUITE";
			
			}else{
				
				cache = "Pas de figure";
				
			}
			
		}
		
		compteur = 0;
		
		if (cache.equals(figure) 
			|| (figure.equals("PSUITE") && (cache.equals("GSUITE")))
			|| (figure.equals("BRELAN") && (cache.equals("CARRE")))
			|| (figure.equals("BRELAN") && (cache.equals("FULL")))
			|| (figure.equals("BRELAN") && (cache.equals("YAHTZEE")))
			|| (figure.equals("CARRE") && (cache.equals("YAHTZEE")))){
			
			return true;
			
		}
		
		return false;
		
	}

	public int getScoreUn() {
		return scoreUn;
	}

	public int getScoreDeux() {
		return scoreDeux;
	}

	public int getScoreTrois() {
		return scoreTrois;
	}

	public int getScoreQuatre() {
		return scoreQuatre;
	}

	public int getScoreCinq() {
		return scoreCinq;
	}

	public int getScoreSix() {
		return scoreSix;
	}

	public int getScoreChance() {
		return scoreChance;
	}

	public int getScoreBrelan() {
		return scoreBrelan;
	}

	public int getScoreCarre() {
		return scoreCarre;
	}

	public int getScoreFull() {
		return scoreFull;
	}

	public int getScorePSuite() {
		return scorePSuite;
	}

	public int getScoreGSuite() {
		return scoreGSuite;
	}

	public int getScoreYahtzee() {
		return scoreYahtzee;
	}

	public int getScoreSTotal1() {
		return scoreSTotal1;
	}

	public int getScoreSTotal2() {
		return scoreSTotal2;
	}

	public int getScoreBonus() {
		return scoreBonus;
	}

	public int getScoreTotal() {
		return scoreTotal;
	}
	
}
