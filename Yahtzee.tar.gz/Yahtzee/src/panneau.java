import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JPanel;


public class panneau extends JPanel{
	
	private static ArrayList<deGraphic> carres = new ArrayList<deGraphic>();
	private int numLancer = -1;
	private int numTour = -1;
	private String langue = "";
	private Font police = new Font("times new roman", Font.BOLD, 20);
	
	public panneau(){
		
		deGraphic carre1 = new deGraphic();
		deGraphic carre2 = new deGraphic();
		deGraphic carre3 = new deGraphic();
		deGraphic carre4 = new deGraphic();
		deGraphic carre5 = new deGraphic();
		
		carres.add(carre1);
		carres.add(carre2);
		carres.add(carre3);
		carres.add(carre4);
		carres.add(carre5);
		
	}
	
	public void paintComponent(Graphics g){

		super.paintComponent(g);
		
		for (int i = 0; i < 5; i++){
			
			this.calculCoordonnees(carres.get(i), i);
			carres.get(i).dessine(g);
			
		}
		
		if (numLancer >= 0 && numTour > 0){
			
			g.setFont(police);
		
			if (langue.equals("FR")){
			
				g.drawString("Lancer "+numLancer+"/3", this.getWidth()*10/100, this.getHeight()*10/100);
				g.drawString("Tour "+numTour+"/13", this.getWidth()*50/100, this.getHeight()*10/100);
				
			}else if (langue.equals("EN")){
				
				g.drawString("Roll "+numLancer+"/3", this.getWidth()*10/100, this.getHeight()*10/100);
				g.drawString("Turn "+numTour+"/13", this.getWidth()*50/100, this.getHeight()*10/100);
				
			}
		}
	}
	
	public void calculCoordonnees(deGraphic cube, int numCarre){
		
		int largeur = this.getWidth();
		int hauteur = this.getHeight();
		int taille = largeur*75/100/5;
		int posx = (int)(this.getWidth()*(2.5)/100);
		
		if (numCarre == 0){
			
			posx = posx + taille/2;
			
		}else{
			
			posx = posx + (posx*2*numCarre) + (taille * numCarre) + taille/2; 
			
		}
		
		cube.setTaille(posx, hauteur/2, taille);
		
	}
	
	public void changeValeurs (int[] valeurs){
		
		for (int i = 0; i < 5; i++){
			
			carres.get(i).setValeur(valeurs[i]);
			
		}
		
	}
	
	public boolean[] testSelection(int x, int y){
		
		int clicX = x;
		int clicY = y;
		boolean resultat[] = new boolean[5];
		
		for (int i = 0; i<5; i++){
			
			resultat[i] = false;
			
		}
		
		for (int i = 0; i<5; i++){
			
			if (carres.get(i).contient(clicX, clicY)){
			
			resultat[i] = true;
			
			}
			
		}
		
		return resultat;
		
	}
	
	public void setSelection(boolean retour[]){
		
		for (int i = 0; i < 5; i++){
			
			if (retour[i]){
				
				carres.get(i).setSelected(true);
				
			}else{
				
				carres.get(i).setSelected(false);
				
			}
			
		}
		
	}
	
	public void setActivite (boolean actif){
		
		for (int i = 0; i < 5; i++){
			
			carres.get(i).setActif(actif);
			
		}
		
	}
	
	public void setLangue (String langue){
		
		this.langue = langue;
		
	}
	
	public void setNumLancer (int numLancer){
		
		this.numLancer = numLancer;
		
	}
	
	public void setNumTour (int numTour){
		
		this.numTour = numTour;
		
	}
	
}
